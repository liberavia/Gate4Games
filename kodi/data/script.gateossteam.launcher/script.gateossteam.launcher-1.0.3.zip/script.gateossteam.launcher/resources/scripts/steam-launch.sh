#!/bin/bash

killall -9 kodi.bin

startx /usr/bin/steamos-session

/usr/bin/kodi -fs