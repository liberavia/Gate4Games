Steam Launcher for gateOS
Based on the original Steam Launcher of teedub

https://www.gate4games.com
http://store.steampowered.com/bigpicture
http://kodi.tv/